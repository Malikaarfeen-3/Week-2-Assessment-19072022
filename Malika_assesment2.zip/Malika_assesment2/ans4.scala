object ans4
{
def main(args: Array[String])
{
 val str = "http://allaboutscala.com"
    val charToFind = str.charAt(7)
    println(s"The 8th character literal in $str = $charToFind")
}
}

