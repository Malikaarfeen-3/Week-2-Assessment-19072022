object ans8
{
def main(args: Array[String])
{
val listRange = List.range(100, 150, 10)
val listRangeAsStr = listRange.mkString(", ")
println(s"Elements of List from 100 to 150, excluding the 150 number literal = $listRangeAsStr")
println(s"Sum for elements in the List = ${listRange.sum}")

}
}

